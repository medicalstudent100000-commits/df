from flask import Flask, request, jsonify, send_from_directory
import os, json
from PyPDF2 import PdfReader

app = Flask(__name__)
UPLOAD_FOLDER = 'sources'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
DATABASE = "knowledge.json"

TEACHER_USERNAME = "Esrra"
TEACHER_PASSWORD = "1234"

if os.path.exists(DATABASE):
    with open(DATABASE, "r", encoding="utf-8") as f:
        knowledge = json.load(f)
else:
    knowledge = []

def extract_text_from_pdfs():
    texts = []
    for fname in os.listdir(UPLOAD_FOLDER):
        if not fname.lower().endswith('.pdf'):
            continue
        path = os.path.join(UPLOAD_FOLDER, fname)
        try:
            reader = PdfReader(path)
            for page in reader.pages:
                txt = page.extract_text()
                if txt:
                    for paragraph in txt.split('\n'):
                        p = paragraph.strip()
                        if len(p) > 40:
                            texts.append(p)
        except Exception as e:
            print(f'⚠️ خطأ في قراءة {fname}: {e}')
    return texts

def find_best_answer(question, texts):
    question = question.lower()
    best_match = None
    score = 0
    for text in texts:
        match = sum(1 for word in question.split() if word in text.lower())
        if match > score:
            score = match
            best_match = text
    return best_match

@app.route('/')
def home():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    question = data.get('question', '').strip()
    if not knowledge:
        return jsonify({'answer': '⚠️ لا توجد مصادر مضافة بعد. اطلب من الأستاذ إضافتها.'})
    answer = find_best_answer(question, knowledge)
    if answer:
        return jsonify({'answer': answer})
    else:
        return jsonify({'answer': 'لم أجد إجابة واضحة في المصادر الحالية 📘'})

@app.route('/login_teacher', methods=['POST'])
def login_teacher():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if username == TEACHER_USERNAME and password == TEACHER_PASSWORD:
        return jsonify({'status': 'ok'})
    return jsonify({'status': 'error', 'error': '❌ بيانات الدخول غير صحيحة'})

@app.route('/upload_source', methods=['POST'])
def upload_source():
    file = request.files.get('file')
    if not file:
        return 'لم يتم اختيار ملف'
    path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(path)
    return f'✅ تم رفع الملف بنجاح: {file.filename}'

@app.route('/list_sources')
def list_sources():
    files = os.listdir(UPLOAD_FOLDER)
    if not files:
        return 'لا توجد ملفات بعد.'
    return '<br>'.join(files)

@app.route('/rebuild_index', methods=['POST'])
def rebuild_index():
    global knowledge
    knowledge = extract_text_from_pdfs()
    with open(DATABASE, 'w', encoding='utf-8') as f:
        json.dump(knowledge, f, ensure_ascii=False, indent=2)
    return f'✅ تم بناء قاعدة المعرفة بنجاح ({len(knowledge)} فقرة تم استخراجها)'

@app.route('/logout_teacher', methods=['POST'])
def logout_teacher():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
